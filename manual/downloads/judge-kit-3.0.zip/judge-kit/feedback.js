'use strict';

/**
 * feedback.js — 判官反馈闭环（零依赖，Node 18+）
 *
 * 流程：
 *   1. judge.js 每判一次，往 judge-log.jsonl 写一条（含 ctx）。
 *   2. node feedback.js list --unlabeled   看最近判了什么
 *   3. node feedback.js label <id> say|silence [--note "为什么"]
 *   4. node feedback.js build              把人工判例写成 examples.json
 *   5. judge.js 下次调用自动把 examples.json 拼进 prompt（few-shot）
 *
 * 这不是训练模型，是「判例学习」：人挑错、人标注、判官照着例子判。
 * 想让在跑的 HTTP 服务立刻生效：POST /reload（见 server.js）。
 *
 * 用法：
 *   node feedback.js stats
 *   node feedback.js list --unlabeled --limit 20
 *   node feedback.js list --verdict 不说 --limit 20
 *   node feedback.js label mabc123 say --note "点它名了"
 *   node feedback.js label mabc124 silence --note "别人互聊"
 *   node feedback.js build --max 8
 */

const fs = require('fs');

const DEFAULTS = { log: 'judge-log.jsonl', labels: 'labels.jsonl', out: 'examples.json' };

function readJsonl(file) {
  try {
    return fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).map((line) => {
      try { return JSON.parse(line); } catch { return null; }
    }).filter(Boolean);
  } catch {
    return [];
  }
}

function parseArgs(argv) {
  const o = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    if (a === '--limit') o.limit = Number(argv[++i]);
    else if (a === '--verdict') o.verdict = argv[++i];
    else if (a === '--unlabeled') o.unlabeled = true;
    else if (a === '--note') o.note = argv[++i];
    else if (a === '--log') o.log = argv[++i];
    else if (a === '--labels') o.labels = argv[++i];
    else if (a === '--out') o.out = argv[++i];
    else if (a === '--max') o.max = Number(argv[++i]);
    else o._.push(a);
  }
  return o;
}

function fmtTime(ts) {
  const d = new Date(Number(ts) || Date.now());
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function lastLabels(file) {
  const map = new Map();
  for (const l of readJsonl(file)) {
    if (l && l.id && (l.label === 'say' || l.label === 'silence')) map.set(l.id, l);
  }
  return map;
}

function statsOf(opts = {}) {
  const logFile = opts.log || DEFAULTS.log;
  const labelsFile = opts.labels || DEFAULTS.labels;
  const log = readJsonl(logFile).filter((r) => r.k === 'judge');
  const labels = lastLabels(labelsFile);
  const verdicts = {};
  const releases = {};
  for (const r of log) {
    const v = r.verdict || '?';
    verdicts[v] = (verdicts[v] || 0) + 1;
    if (r.release) releases[r.release] = (releases[r.release] || 0) + 1;
  }
  const byId = new Map(log.filter((r) => r.id).map((r) => [r.id, r]));
  let compared = 0;
  let agree = 0;
  for (const [id, l] of labels) {
    const r = byId.get(id);
    if (!r) continue;
    compared += 1;
    const want = l.label === 'say';
    const got = r.verdict === '说' || r.verdict === '拿不准';
    if (want === got) agree += 1;
  }
  return {
    total: log.length,
    verdicts,
    releases,
    labels: [...labels.keys()].filter((id) => byId.has(id)).length,
    compared,
    agree,
    agreeRate: compared ? agree / compared : null,
    logFile,
    labelsFile,
  };
}

function printStats(opts) {
  const s = statsOf(opts);
  console.log(`日志：${s.logFile}（判官记录 ${s.total} 条）`);
  console.log('判定分布：' + (Object.keys(s.verdicts).length
    ? Object.entries(s.verdicts).map(([k, v]) => `${k} ${v}`).join(' / ')
    : '（空）'));
  if (Object.keys(s.releases).length) {
    console.log('放行分布：' + Object.entries(s.releases).map(([k, v]) => `${k} ${v}`).join(' / '));
  }
  console.log(`人工标注：${s.labels} 条（能对上日志的）`);
  console.log(`标注与判官一致：${s.agree}/${s.compared}` +
    (s.agreeRate == null ? '' : `（${(s.agreeRate * 100).toFixed(0)}%）`));
  if (s.compared) console.log('提示：一致率低不一定是判官差，先看错在「该说没说」还是「不该说说了」。');
}

function listSamples(opts = {}) {
  const log = readJsonl(opts.log || DEFAULTS.log).filter((r) => r.k === 'judge' && r.id);
  const labels = lastLabels(opts.labels || DEFAULTS.labels);
  let rows = log.slice().sort((a, b) => (b.t || 0) - (a.t || 0));
  if (opts.verdict) rows = rows.filter((r) => r.verdict === opts.verdict);
  if (opts.unlabeled) rows = rows.filter((r) => !labels.has(r.id));
  const limit = Math.max(1, Number(opts.limit) || 20);
  rows = rows.slice(0, limit);
  if (!rows.length) { console.log('没有符合条件的记录。'); return rows; }
  for (const r of rows) {
    const mark = labels.has(r.id) ? (labels.get(r.id).label === 'say' ? '✓说' : '✓不说') : '  ?';
    const rel = r.release ? `→放行(${r.release})` : '';
    console.log(`${r.id}  ${fmtTime(r.t)}  ${r.key || '-'}  ${mark}  ${r.verdict}${rel}  ${r.why || ''}`);
    if (Array.isArray(r.ctx) && r.ctx.length) {
      const tail = r.ctx.slice(-3).map((m) => `${m.me ? '[它]' : ''}${m.s || '?'}: ${m.x || ''}`).join('  |  ');
      console.log('    ' + tail);
    }
  }
  return rows;
}

function labelSample(opts = {}) {
  const [id, label] = opts._ || [];
  if (!id || !['say', 'silence'].includes(label)) {
    throw new Error('用法：node feedback.js label <id> say|silence [--note "为什么"]');
  }
  const log = readJsonl(opts.log || DEFAULTS.log).filter((r) => r.k === 'judge');
  if (!log.some((r) => r.id === id)) throw new Error('日志里找不到 id：' + id);
  const rec = { id, label, note: String(opts.note || '').slice(0, 80), ts: Date.now() };
  fs.appendFileSync(opts.labels || DEFAULTS.labels, JSON.stringify(rec) + '\n', 'utf8');
  return rec;
}

function buildExamples(opts = {}) {
  const logFile = opts.log || DEFAULTS.log;
  const labelsFile = opts.labels || DEFAULTS.labels;
  const outFile = opts.out || DEFAULTS.out;
  const max = Math.max(1, Number(opts.max) || 8);

  const log = readJsonl(logFile).filter((r) => r.k === 'judge' && r.id
    && Array.isArray(r.ctx) && r.ctx.length);
  const byId = new Map(log.map((r) => [r.id, r]));
  const picks = [];
  for (const [id, l] of lastLabels(labelsFile)) {
    const r = byId.get(id);
    if (r) picks.push({ id, l, r });
  }
  picks.sort((a, b) => (b.r.t || 0) - (a.r.t || 0));

  const half = Math.ceil(max / 2);
  const say = picks.filter((p) => p.l.label === 'say').slice(0, half);
  const silence = picks.filter((p) => p.l.label === 'silence').slice(0, half);
  let sel = say.concat(silence);
  if (sel.length < max) {
    const used = new Set(sel.map((p) => p.id));
    sel = sel.concat(picks.filter((p) => !used.has(p.id)).slice(0, max - sel.length));
  }
  sel = sel.slice(0, max);

  const examples = sel.map(({ l, r }) => ({
    verdict: l.label === 'say' ? '说' : '不说',
    why: String(l.note || r.why || '').slice(0, 30),
    messages: r.ctx.map((m) => ({
      self: !!m.me,
      name: String(m.s || ''),
      text: String(m.x || ''),
      time: Number(m.t || 0) || undefined,
    })),
  }));

  let backup = '';
  try {
    if (fs.existsSync(outFile)) {
      backup = outFile + '.bak-' + new Date().toISOString().replace(/[:.]/g, '-');
      fs.copyFileSync(outFile, backup);
    }
  } catch { /* 备份失败不阻断 */ }
  fs.writeFileSync(outFile, JSON.stringify(examples, null, 2) + '\n', 'utf8');
  return {
    written: examples.length,
    say: examples.filter((e) => e.verdict === '说').length,
    silence: examples.filter((e) => e.verdict === '不说').length,
    file: outFile,
    backup,
  };
}

function usage() {
  console.log(`用法：
  node feedback.js stats
  node feedback.js list [--unlabeled] [--verdict 说|不说|拿不准] [--limit 20]
  node feedback.js label <id> say|silence [--note "为什么"]
  node feedback.js build [--max 8]
公共参数：--log judge-log.jsonl  --labels labels.jsonl  --out examples.json`);
}

if (require.main === module) {
  const opts = parseArgs(process.argv.slice(2));
  const cmd = opts._[0];
  try {
    if (cmd === 'stats') {
      printStats(opts);
    } else if (cmd === 'list') {
      listSamples(opts);
    } else if (cmd === 'label') {
      const rec = labelSample(opts);
      console.log(`已标注 ${rec.id} → ${rec.label}${rec.note ? '（' + rec.note + '）' : ''}`);
    } else if (cmd === 'build') {
      const r = buildExamples(opts);
      console.log(`已写 ${r.file}：${r.written} 条（说 ${r.say} / 不说 ${r.silence}）` +
        (r.backup ? `；旧文件备份到 ${r.backup}` : ''));
      console.log('让正在跑的服务立刻生效：POST /reload（或重启你的鱼）。');
    } else {
      usage();
    }
  } catch (e) {
    console.error(String((e && e.message) || e));
    process.exit(1);
  }
}

module.exports = { readJsonl, parseArgs, statsOf, listSamples, labelSample, buildExamples, lastLabels };

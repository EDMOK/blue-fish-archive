# judge-kit — 群聊 AI 判官「全套」

给群聊里的 AI 加一层**判官**：被叫醒之后、真正开口之前，先让一个小模型判「这一刻该不该说话」。判「不说」就不跑回合、不花回复的 token。

这个包是**可交接的完整版**：核心判官 + 人工反馈闭环 + HTTP 服务 + 离线自测。

> 一句话：判官负责「这次说不说」；`feedback.js` 负责把人的纠正变成判例，让判官**越用越准**——但这不是训练模型，是 few-shot 判例学习。

## 包里有什么

| 文件 | 作用 |
|---|---|
| `judge.js` | 判官核心：读最近 12 条、调模型、返回 `speak`；带每日上限/宽松率/静默释放/异常放行 |
| `feedback.js` | 反馈闭环：`stats` / `list` / `label` / `build`，把人工标注写成 `examples.json` |
| `server.js` | 把判官包成 HTTP 服务，给非 Node 的鱼用 |
| `selftest.js` | 离线自测（mock 模型，不连网、不花 token） |
| `examples.json` | 人工判例（初始为空 `[]`，由 `feedback.js build` 生成） |
| `README.md` | 本文件 |

零依赖，只要 **Node 18+**（需要全局 `fetch`）。

## 快速开始

```bash
# 1. 自测（不用 key）
node selftest.js

# 2. 接进你的鱼（Node）
DEEPSEEK_API_KEY=sk-xxx node your-bot.js
```

最小接入：

```js
const { createJudge } = require('./judge');

const judge = createJudge({
  apiKey: process.env.DEEPSEEK_API_KEY,
  logFile: './judge-log.jsonl',   // 想用反馈闭环就填
  selfNames: ['本鱼'],            // 改成你这只鱼的名字
});

// 在你的「唤醒之后、生成回复之前」调用
async function onWake(ctx) {
  const r = await judge.shouldSpeak(ctx.messages, {
    isGroup: true,
    tier: ctx.tier,               // 'high' | 'chat' | 'low'
    key: ctx.key,                 // 'group:123456'
    lastReplyAt: ctx.lastReplyAt, // 这个群上次说话的时间（毫秒），没有就 0
  });

  if (!r.speak) {
    console.log('[judge] 这轮不开口：' + r.why);
    return;                       // 关键：真的不要生成/发送
  }
  await ctx.reply(await ctx.generate());
}
```

`ctx.messages` 按时间从旧到新，最后一条是刚收到的；每条：

```js
{ self: false, name: '群友A', text: '...', time: 1795000000000, owner: false }
```

- `self: true`：这条是鱼自己说的；
- `owner: true`：主人说的（可选，判官会参考）。

判官只看最后 **12 条**。

## 给非 Node 的鱼：HTTP 模式

```bash
node server.js --port 8787 --token 换成你的口令 --key sk-xxx
# 或者：DEEPSEEK_API_KEY=sk-xxx JUDGE_TOKEN=xxx node server.js
```

```bash
curl -s http://127.0.0.1:8787/judge \
  -H 'authorization: Bearer 换成你的口令' \
  -H 'content-type: application/json' \
  -d '{
    "messages": [
      {"name":"群友A","text":"今晚吃啥"},
      {"name":"群友B","text":"火锅"},
      {"name":"群友C","text":"@本鱼 你来吗"}
    ],
    "opts": {"key":"group:123","tier":"chat","isGroup":true}
  }'
```

返回：

```json
{"speak":true,"skipped":false,"verdict":"说","why":"点它名了","release":""}
```

其它路由：

- `GET /health` → `{"ok":true,"examples":3,"used":12}`
- `POST /reload` → 重新读 `examples.json`（反馈闭环用，需要口令）

默认只监听 `127.0.0.1`；要跨机访问就自己加 `--host 0.0.0.0` 并务必设口令。

## 让它「越用越准」：反馈闭环

这就是「全套」和「一个 judge.js」的区别。

```bash
# 1. 看统计：判了多少、说/不说比例、标注一致率
node feedback.js stats

# 2. 挑没标注的看（默认最近 20 条）
node feedback.js list --unlabeled
node feedback.js list --verdict 不说 --limit 30

# 3. 人工判：它当时该不该说
node feedback.js label mabc123 say --note "点它名了"
node feedback.js label mabc124 silence --note "别人互聊"

# 4. 把标注写成判例（默认最多 8 条，说/不说各半）
node feedback.js build --max 8

# 5. 让正在跑的服务立刻生效
curl -X POST http://127.0.0.1:8787/reload -H 'authorization: Bearer 口令'
```

`build` 会写 `examples.json`，格式：

```json
[
  {
    "verdict": "不说",
    "why": "别人互聊，没点它",
    "messages": [
      {"name": "群友A", "text": "今晚吃啥", "self": false},
      {"name": "群友B", "text": "火锅", "self": false},
      {"name": "群友A", "text": "走", "self": false}
    ]
  }
]
```

判官下次调用会把最多 8 条判例拼在 system prompt 后面（「参考判例（人工标注，按这个尺度判）」）。**这是判例学习，不是训练模型**：判错的样本靠人挑、人标，判官照着例子改尺度。

建议节奏：第一周每天看 10 条，之后每周一次。优先标两类：

1. 判官说「不说」但你觉得它其实该接的（错过）；
2. 判官说「说」但明显是在插嘴的（多嘴）。

## 配置

| 选项 | 默认 | 说明 |
|---|---|---|
| `apiKey` | `DEEPSEEK_API_KEY` | 必填，否则所有判都跳过（放行） |
| `baseUrl` | `https://api.deepseek.com` | OpenAI 兼容接口 |
| `model` | `deepseek-chat` | 要支持 `response_format: json_object` |
| `maxPerDay` | `400` | 每天最多判几次，0 = 全跳过 |
| `timeoutMs` | `9000` | 超时即放行 |
| `loosePassRate` | `0.25` | 判「不说」也随机放行的比例 |
| `quietReleaseMin` | `25` | 超过多少分钟没在这个群说话，判「不说」也放行一次；不传 `lastReplyAt` 则不做静默释放 |
| `logFile` | 空 | 填了才写 JSONL（反馈闭环需要） |
| `prompt` | 内置 | 要改判准就改这里 |
| `selfNames` | `['本鱼']` | 鱼的名字，用于「点名你」标记 |
| `examplesFile` | 同目录 `examples.json` | 人工判例 |
| `logger` | 空函数 | 想接自己的日志就传 |

## 返回值

| 情况 | 返回 |
|---|---|
| 该说 / 拿不准 | `{speak:true, skipped:false, verdict:'说'\|'拿不准', why, release:''}` |
| 不该说 | `{speak:false, skipped:false, verdict:'不说', why, release:''}` |
| 私聊 / 高档 / 额度满 / 没 key / 上下文 < 3 | `{speak:true, skipped:true, verdict:'skip', why, release:''}` |
| 判「不说」但静默/宽松放行 | `{speak:true, skipped:false, verdict:'不说', why, release:'quiet'\|'loose'}` |
| 超时 / HTTP 错 / JSON 坏 | `{speak:true, skipped:true, verdict:'skip', why:'异常放行…', release:'error'}` |

`skipped:true` 一律照常回复；**只有 `speak:false` 才拦**。

## 分档建议

| 档 | 什么时候 | 判不判 |
|---|---|---|
| `high` | @、点名、直接提问、主人说话 | 不判，直接回 |
| `chat` | 接话、关键词、话题在它身上 | 判（主力） |
| `low` | 随机/概率唤醒 | 判，且可以更严 |

判官是「第二道闸」：第一道是唤醒（值不值得跑回合），第二道才是它（该不该开口）。两道都省，别只加一道。

## 成本

一次判官 = 最近 12 条上下文 + 固定 prompt，大约几百 token；一天 400 次也就是几十万 token 量级。按你用的模型价目表算，通常一天几毛到一两块，比「每轮都跑完整回复」便宜一个量级。

## 坑

- **`selfNames` 一定要改**。默认是「本鱼」，不改成你的鱼名，「点名你」标记会失效。
- **同名第三人称是最大误判源**：句子里出现鱼名但没 @、是第三人在评价（「这大肥鱼」「我家的鱼」「截图里」），要判「不说」；prompt 里已经写了，但例子最好也补。
- 判官只负责「判」，**不负责拦**：你的代码必须真的在 `speak:false` 时不生成、不发送。
- 判「不说」不等于消息没入库；它只是不跑回合。
- 日志里有群聊原文（`ctx`），注意隐私和清理；`judge-log.jsonl` 默认最多留 2500 条（每 200 次写检查一次）。
- 非 DeepSeek 的模型要确认支持 `response_format: json_object`，否则会走 fail-open。
- 判官是「软」判断，别拿它当审核/风控；它只决定「接不接话」。

## 自测

```bash
node selftest.js
```

覆盖：说 / 不说 / 高档跳过 / 私聊跳过 / 静默释放 / 宽松放行 / 判例加载 / 判例进 prompt / `build` / `stats` / `label`。全 PASS 再拿去接。

## 最小排障

| 现象 | 先看 |
|---|---|
| 全都不拦 | `stats().used` 是否一直 0：没 key / 额度满 / 上下文 < 3 / tier 是 high |
| 一直拦太狠 | `loosePassRate` 调高、`quietReleaseMin` 调小；看 `feedback.js list --verdict 不说` |
| 判得慢 | `timeoutMs` 调小；模型换更快的小模型 |
| 反馈不生效 | 服务有没有 `POST /reload`；`examples.json` 是否合法 JSON；条数是否 > 8 |

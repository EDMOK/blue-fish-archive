'use strict';

/**
 * judge.js — 群聊 AI「该不该开口」判官（零依赖，Node 18+）
 *
 * 作用：在「机器人被叫醒」和「真的开口」之间插一层小模型判定。
 *       判「不说」就不回 —— 这一轮等于没发生，不跑回合、不花回复的 token。
 *
 * 用法：
 *   const { createJudge } = require('./judge');
 *   const judge = createJudge({
 *     apiKey: process.env.DEEPSEEK_API_KEY,
 *     logFile: './judge-log.jsonl',
 *   });
 *
 *   const r = await judge.shouldSpeak(messages, {
 *     isGroup: true,          // 私聊传 false，直接放行
 *     tier: 'chat',           // 'high' 直接放行（@/点名/提问/主人）
 *     key: 'group:123456',
 *     lastReplyAt: 1795000000000, // 这个群上次说话的时间（毫秒），用于静默释放
 *   });
 *   if (r.speak) { ...正常回复... } else { ...这轮不开口... }
 *
 * messages 格式（按时间从旧到新，最后一条是刚收到的）：
 *   [{ self: false, name: '群友A', text: '...', time: 1795000000000, owner: false }, ...]
 *
 * 返回：
 *   { speak: true,  skipped: false, verdict: '说'|'拿不准', why, release: '' }
 *   { speak: false, skipped: false, verdict: '不说', why, release: '' }
 *   { speak: true,  skipped: true,  verdict: 'skip', why, release: 'loose'|'quiet'|'error'|'' }
 *   skipped=true 表示判官没判（私聊/高档/额度满/没 key/上下文少），调用方照常回复。
 *
 * 学习（反馈闭环）：
 *   examples.json 是可选的「人工判例」文件，格式：
 *   [{ "verdict":"说", "why":"点它名了", "messages":[{ "name":"群友A", "text":"..." }, ...] }]
 *   判官每次调用会把它拼在 system prompt 后面，作为 few-shot 参考。
 *   用 feedback.js 从 judge-log.jsonl 里挑样本、人工标注、再生成 examples.json。
 *
 * 规则要点：
 *   - 高档不判、私聊不判、上下文 < 3 条不判、每天上限 400 次。
 *   - 判「不说」也按 loosePassRate（默认 25%）随机放行。
 *   - 超过 quietReleaseMin（默认 25 分钟）没在这个群说话，判「不说」也放行一次。
 *   - 超时/HTTP 错/JSON 解析失败一律 fail-open（放行）。
 */

const fs = require('fs');
const path = require('path');

const DEFAULT_EXAMPLES_FILE = path.join(__dirname, 'examples.json');

const DEFAULT_PROMPT = `你是群聊里的旁观者，替一个 AI 机器人把关：它这一刻该不该开口。
机器人自称「本鱼」，上下文里标记为〔你自己说的〕。

判断标准：最新这些消息里，有没有明确在跟它说——点它名字、@它、直接问它、或者接着它上一句。
内容相关不等于该说话；群里别人互相聊、没人问它，它就该沉默。
把「不说」只留给一眼就知道跟它无关的（别人聊自己的事、互相调侃、讨论别的 AI）。

特别注意：句子里出现「大肥鱼/小鲸鱼/肥鱼」但**没有 @ 它**、而且是第三人称在评价（「这大肥鱼」「那条鱼」「我家的鱼」「截图里」）——那是别人家的 AI，判「不说」。

有人抛问题、有人吐槽、有人接着它刚说过的话往下聊——这些都算有由头，倾向「说」。
还有一类也算有由头：最后几条是在说它、说它刚发的图/语音、或者它刚参与过的话题还在往下走——不用等它被点名，它在场就该接。

拿不准的时候倾向「拿不准」，不要硬判「不说」。
输出 JSON：{"verdict":"说|不说|拿不准","why":"十个字以内"}`;

function clamp01(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return 0;
  return Math.max(0, Math.min(1, v));
}

function clip(s, n) {
  const a = Array.from(String(s == null ? '' : s));
  return a.length <= n ? a.join('') : a.slice(0, n).join('') + '…';
}

function dayKey(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function hhmm(ts) {
  const d = new Date(Number(ts) || Date.now());
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

function readExamples(file) {
  try {
    const arr = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!Array.isArray(arr)) return [];
    return arr
      .filter((e) => e && (e.verdict === '说' || e.verdict === '不说')
        && Array.isArray(e.messages) && e.messages.length)
      .slice(0, 8);
  } catch {
    return [];
  }
}

function examplesBlock(examples) {
  if (!Array.isArray(examples) || !examples.length) return '';
  const lines = examples.slice(0, 8).map((e, i) => {
    const dialog = e.messages.slice(-4).map((m) => {
      const who = m && m.self ? '〔它自己〕' : '';
      return `${who}${clip((m && m.name) || '?', 12)}：` +
        clip(String((m && m.text) || '').replace(/\s+/g, ' '), 60);
    }).join(' / ');
    const why = e.why ? `（${clip(e.why, 20)}）` : '';
    return `${i + 1}. ${dialog} → ${e.verdict}${why}`;
  });
  return '\n\n参考判例（人工标注，按这个尺度判）：\n' + lines.join('\n');
}

function createJudge(options = {}) {
  if (typeof fetch !== 'function' || typeof AbortController !== 'function') {
    throw new Error('judge.js 需要 Node 18+（global fetch / AbortController）');
  }

  const cfg = {
    apiKey: options.apiKey || process.env.DEEPSEEK_API_KEY || '',
    baseUrl: String(options.baseUrl || 'https://api.deepseek.com').replace(/\/+$/, ''),
    model: options.model || 'deepseek-chat',
    maxPerDay: Math.max(0, Number(options.maxPerDay == null ? 400 : options.maxPerDay) || 0),
    timeoutMs: Math.max(1000, Number(options.timeoutMs == null ? 9000 : options.timeoutMs) || 9000),
    loosePassRate: clamp01(options.loosePassRate == null ? 0.25 : options.loosePassRate),
    quietReleaseMin: Math.max(0, Number(options.quietReleaseMin == null ? 25 : options.quietReleaseMin) || 0),
    logFile: options.logFile || '',
    prompt: options.prompt || DEFAULT_PROMPT,
    selfNames: Array.isArray(options.selfNames) && options.selfNames.length
      ? options.selfNames.map(String).filter(Boolean)
      : ['本鱼'],
    examplesFile: options.examplesFile || DEFAULT_EXAMPLES_FILE,
    examples: [],
    logger: typeof options.logger === 'function' ? options.logger : () => {},
  };

  cfg.examples = readExamples(cfg.examplesFile);

  let usedDay = '';
  let used = 0;
  let writes = 0;

  function append(rec) {
    if (!cfg.logFile) return;
    try {
      fs.appendFileSync(cfg.logFile, JSON.stringify(rec) + '\n', 'utf8');
      writes += 1;
      if (writes % 200 === 0) {
        const lines = fs.readFileSync(cfg.logFile, 'utf8').split('\n').filter(Boolean);
        if (lines.length > 2600) {
          fs.writeFileSync(cfg.logFile, lines.slice(-2500).join('\n') + '\n', 'utf8');
        }
      }
    } catch { /* 记录失败不影响判断 */ }
  }

  function systemPrompt() {
    return cfg.prompt + examplesBlock(cfg.examples);
  }

  function reloadExamples() {
    cfg.examples = readExamples(cfg.examplesFile);
    return cfg.examples.length;
  }

  function exampleCount() {
    return cfg.examples.length;
  }

  function isAddr(text) {
    const t = String(text || '').toLowerCase();
    return cfg.selfNames.some((n) => t.includes(String(n).toLowerCase()));
  }

  function featsOf(list, lastReplyAt) {
    const last = list[list.length - 1] || {};
    const now = Date.now();
    const mine10 = list.filter((m) => m && m.self && now - Number(m.time || 0) < 600000).length;
    const others2 = list.filter((m) => m && !m.self && now - Number(m.time || 0) < 120000).length;
    const lastSelf = [...list].reverse().find((m) => m && m.self);
    return {
      nCtx: list.length,
      lastSelf: !!last.self,
      lastOwner: !!last.owner,
      namedMe: isAddr(last.text),
      lastLen: String(last.text || '').length,
      minSinceMine: lastSelf ? Math.round((now - Number(lastSelf.time || now)) / 60000) : null,
      mine10,
      others2,
      sinceLastReplyMin: lastReplyAt ? Math.round((now - lastReplyAt) / 60000) : null,
    };
  }

  function ctxOf(list) {
    try {
      return list.map((m) => ({
        me: !!m.self,
        s: clip(m.name || '', 24),
        x: clip(String(m.text || '').replace(/\s+/g, ' '), 80),
        t: Number(m.time || 0) || null,
      }));
    } catch {
      return [];
    }
  }

  async function shouldSpeak(messages, opts = {}) {
    const t0 = Date.now();
    const key = String(opts.key || '');
    const isGroup = opts.isGroup !== false;
    const tier = String(opts.tier || 'chat');
    const lastReplyAt = Number(opts.lastReplyAt || 0);
    const list = Array.isArray(messages) ? messages.slice(-12) : [];

    const skip = (why, release = '') => {
      cfg.logger('[judge] 跳过：' + why);
      append({ k: 'skip', t: Date.now(), key, tier, why, ms: Date.now() - t0 });
      return { speak: true, skipped: true, verdict: 'skip', why, release };
    };

    if (!isGroup) return skip('私聊不判');
    if (tier === 'high') return skip('高档直接放行');

    const day = dayKey();
    if (day !== usedDay) {
      usedDay = day;
      used = 0;
    }
    if (used >= cfg.maxPerDay) return skip(`当日判断次数用满 ${cfg.maxPerDay}`);
    if (!cfg.apiKey) return skip('没有 apiKey');
    if (list.length < 3) return skip('上下文不足 3 条');

    const lines = list.map((m) => {
      const who = m && m.self ? '〔你自己说的〕' : (m && isAddr(m.text) ? '〔点名你〕' : '');
      return `[${hhmm(m && m.time)}]${who} ${clip((m && m.name) || '?', 24)}：` +
        clip(String((m && m.text) || '').replace(/\s+/g, ' '), 110);
    });
    const user = `最近 ${list.length} 条群聊：\n${lines.join('\n')}\n\n现在这一刻，它该不该开口？`;

    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), cfg.timeoutMs);
    try {
      used += 1;
      const resp = await fetch(cfg.baseUrl + '/chat/completions', {
        method: 'POST',
        signal: ctrl.signal,
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${cfg.apiKey}`,
        },
        body: JSON.stringify({
          model: cfg.model,
          temperature: 0,
          max_tokens: 60,
          response_format: { type: 'json_object' },
          messages: [
            { role: 'system', content: systemPrompt() },
            { role: 'user', content: user },
          ],
        }),
      });
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      const json = await resp.json();
      const text = (json && json.choices && json.choices[0] && json.choices[0].message
        && json.choices[0].message.content) || '{}';
      const parsed = JSON.parse(text);
      const verdict = String(parsed.verdict || '').trim();
      if (!['说', '不说', '拿不准'].includes(verdict)) {
        return skip('模型返回非法 verdict: ' + String(text).slice(0, 40), 'error');
      }
      const why = String(parsed.why || '').slice(0, 20);

      let release = '';
      let speak = verdict === '说' || verdict === '拿不准';

      if (verdict === '不说') {
        const quietMs = lastReplyAt > 0 ? Date.now() - lastReplyAt : 0;
        if (quietMs > cfg.quietReleaseMin * 60 * 1000) {
          release = 'quiet';
        } else if (cfg.loosePassRate > 0 && Math.random() < cfg.loosePassRate) {
          release = 'loose';
        }
        speak = !!release;
      }

      const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      append({
        k: 'judge',
        id,
        t: Date.now(),
        key,
        tier,
        verdict,
        why,
        release,
        ms: Date.now() - t0,
        feats: featsOf(list, lastReplyAt),
        ctx: ctxOf(list),
      });

      const tag = verdict === '不说'
        ? (release ? `不说→放行(${release})` : '不说')
        : verdict;
      cfg.logger(`[judge] ${tag}：${why}`);

      return { speak, skipped: false, verdict, why, release };
    } catch (e) {
      const why = e && e.name === 'AbortError' ? '超时' : String((e && e.message) || e);
      cfg.logger('[judge] 异常放行：' + why);
      append({ k: 'judge', t: Date.now(), key, tier, verdict: 'skip', why: '异常放行：' + why, release: 'error', ms: Date.now() - t0, ctx: ctxOf(list) });
      return { speak: true, skipped: true, verdict: 'skip', why: '异常放行：' + why, release: 'error' };
    } finally {
      clearTimeout(timer);
    }
  }

  function stats() {
    return { day: usedDay || dayKey(), used, maxPerDay: cfg.maxPerDay, examples: cfg.examples.length };
  }

  return { shouldSpeak, stats, reloadExamples, exampleCount };
}

module.exports = { createJudge, DEFAULT_PROMPT, readExamples, examplesBlock };

// 直接跑：node judge.js 会做一次自检（无 key 时只验证跳过路径，不发请求）
if (require.main === module) {
  const judge = createJudge({ apiKey: process.env.DEEPSEEK_API_KEY || '', logFile: '' });
  judge.shouldSpeak(
    [
      { self: false, name: '群友A', text: '这大肥鱼今天怎么不说话', time: Date.now() - 120000 },
      { self: false, name: '群友B', text: '可能在忙吧', time: Date.now() - 60000 },
      { self: false, name: '群友C', text: '@大肥鱼 出来聊天', time: Date.now() },
    ],
    { isGroup: true, tier: 'chat', key: 'group:demo' }
  ).then((r) => console.log(JSON.stringify(r, null, 2)));
}

'use strict';

/**
 * selftest.js — 离线自测（不连网，不花 token）
 * 运行：node selftest.js
 */

const fs = require('fs');
const os = require('os');
const path = require('path');

const { createJudge } = require('./judge');
const fb = require('./feedback');

let pass = 0;
let fail = 0;
function ok(name, cond, extra) {
  if (cond) {
    pass += 1;
    console.log('PASS ' + name);
  } else {
    fail += 1;
    console.log('FAIL ' + name + (extra ? '  ' + extra : ''));
  }
}

let lastBody = null;
let mode = 'say';

global.fetch = async (url, init) => {
  lastBody = JSON.parse(init.body);
  const content = mode === 'say'
    ? '{"verdict":"说","why":"在问它"}'
    : '{"verdict":"不说","why":"别人互聊"}';
  return { ok: true, json: async () => ({ choices: [{ message: { content } }] }) };
};

function judgeFile(tmp) {
  return path.join(tmp, 'judge-log.jsonl');
}

(async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'judge-kit-'));
  try {
    const msgs = [
      { self: false, name: 'A', text: '今天吃啥', time: Date.now() - 120000 },
      { self: false, name: 'B', text: '火锅', time: Date.now() - 60000 },
      { self: false, name: 'C', text: '@本鱼 你来吗', time: Date.now() },
    ];

    const j = createJudge({ apiKey: 'x', logFile: judgeFile(tmp), loosePassRate: 0, quietReleaseMin: 25 });
    let r = await j.shouldSpeak(msgs, { isGroup: true, tier: 'chat', key: 'group:test' });
    ok('说 → speak', r.speak === true && r.verdict === '说' && !r.skipped, JSON.stringify(r));

    r = await j.shouldSpeak(msgs, { isGroup: true, tier: 'high' });
    ok('高档 → skip', r.speak === true && r.skipped === true, JSON.stringify(r));

    r = await j.shouldSpeak(msgs, { isGroup: false, tier: 'chat' });
    ok('私聊 → skip', r.speak === true && r.skipped === true, JSON.stringify(r));

    mode = 'no';
    r = await j.shouldSpeak(msgs, { isGroup: true, tier: 'chat' });
    ok('不说 → 沉默', r.speak === false && r.verdict === '不说' && !r.release, JSON.stringify(r));

    r = await j.shouldSpeak(msgs, {
      isGroup: true, tier: 'chat', lastReplyAt: Date.now() - 30 * 60 * 1000,
    });
    ok('不说 → 静默释放', r.speak === true && r.release === 'quiet', JSON.stringify(r));

    const jLoose = createJudge({ apiKey: 'x', logFile: '', loosePassRate: 1 });
    r = await jLoose.shouldSpeak(msgs, { isGroup: true, tier: 'chat' });
    ok('宽松率 1 → 放行', r.speak === true && r.release === 'loose', JSON.stringify(r));

    // 判例加载
    const exFile = path.join(tmp, 'examples.json');
    fs.writeFileSync(exFile, JSON.stringify([{
      verdict: '不说',
      why: '别人互聊',
      messages: [{ name: 'A', text: '今晚吃啥' }, { name: 'B', text: '火锅' }, { name: 'A', text: '走' }],
    }]), 'utf8');
    mode = 'say';
    const jEx = createJudge({ apiKey: 'x', logFile: '', examplesFile: exFile });
    await jEx.shouldSpeak(msgs, { isGroup: true, tier: 'chat' });
    ok('examples 加载计数', jEx.exampleCount() === 1, String(jEx.exampleCount()));
    ok('system prompt 含判例', !!(lastBody && lastBody.messages[0].content.includes('参考判例')
      && lastBody.messages[0].content.includes('火锅')), '');

    // feedback 闭环
    const fbLog = path.join(tmp, 'fb-log.jsonl');
    const fbLabels = path.join(tmp, 'fb-labels.jsonl');
    const fbOut = path.join(tmp, 'fb-examples.json');
    const ctx1 = [{ me: false, s: 'A', x: '今晚吃啥', t: 1 }, { me: false, s: 'B', x: '火锅', t: 2 }];
    const ctx2 = [{ me: false, s: 'A', x: '@本鱼 你来吗', t: 3 }];
    fs.writeFileSync(fbLog, [
      JSON.stringify({ k: 'judge', id: 'a1', t: 1, key: 'group:1', verdict: '不说', why: '别人互聊', ctx: ctx1 }),
      JSON.stringify({ k: 'judge', id: 'a2', t: 2, key: 'group:1', verdict: '说', why: '点它名了', ctx: ctx2 }),
    ].join('\n') + '\n', 'utf8');
    fs.writeFileSync(fbLabels, [
      JSON.stringify({ id: 'a1', label: 'silence', note: '确实没叫它' }),
      JSON.stringify({ id: 'a2', label: 'say', note: '点它名了' }),
    ].join('\n') + '\n', 'utf8');

    const built = fb.buildExamples({ log: fbLog, labels: fbLabels, out: fbOut, max: 4 });
    const ex = JSON.parse(fs.readFileSync(fbOut, 'utf8'));
    ok('build 写出 2 条', built.written === 2 && ex.length === 2, JSON.stringify(built));
    ok('build 两类各 1', ex.filter((e) => e.verdict === '说').length === 1
      && ex.filter((e) => e.verdict === '不说').length === 1, JSON.stringify(ex.map((e) => e.verdict)));

    const st = fb.statsOf({ log: fbLog, labels: fbLabels });
    ok('stats 总数/标注/一致', st.total === 2 && st.labels === 2 && st.compared === 2 && st.agree === 2,
      JSON.stringify(st));

    const rec = fb.labelSample({ _: ['a2', 'silence'], note: '改判', log: fbLog, labels: fbLabels });
    ok('label 追加', rec.id === 'a2' && rec.label === 'silence' && rec.note === '改判', JSON.stringify(rec));
  } finally {
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch { /* ignore */ }
  }

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch((e) => {
  console.error(e);
  process.exit(1);
});

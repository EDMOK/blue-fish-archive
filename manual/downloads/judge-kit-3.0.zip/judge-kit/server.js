'use strict';

/**
 * server.js — 把判官包成 HTTP 服务（零依赖，Node 18+）
 *
 * 给「鱼不是 Node 写的」的人用：任何语言 POST 一下就能问该不该开口。
 *
 * 启动：
 *   node server.js --port 8787 --token 换成你的口令 --key sk-xxx
 *   # 或者：DEEPSEEK_API_KEY=sk-xxx JUDGE_TOKEN=xxx node server.js
 *
 * 调用：
 *   curl -s http://127.0.0.1:8787/judge \
 *     -H 'authorization: Bearer 换成你的口令' \
 *     -H 'content-type: application/json' \
 *     -d '{"messages":[{"name":"群友A","text":"今晚吃啥"},{"name":"群友B","text":"火锅"},{"name":"群友C","text":"@本鱼 你来吗"}],"opts":{"key":"group:123","tier":"chat","isGroup":true}}'
 *
 *   → {"speak":true,"skipped":false,"verdict":"说","why":"点它名了","release":""}
 *
 * 其它：
 *   GET  /health   → {"ok":true,"examples":3,"used":12}
 *   POST /reload   → 重新读 examples.json（反馈闭环用；需要口令）
 */

const http = require('http');
const { createJudge } = require('./judge');

function parseArgs(argv) {
  const o = {};
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    if (a === '--port') o.port = Number(argv[++i]);
    else if (a === '--host') o.host = argv[++i];
    else if (a === '--token') o.token = argv[++i];
    else if (a === '--key') o.key = argv[++i];
    else if (a === '--examples') o.examples = argv[++i];
    else if (a === '--log') o.log = argv[++i];
    else if (a === '--model') o.model = argv[++i];
    else if (a === '--base-url') o.baseUrl = argv[++i];
  }
  return o;
}

const opts = parseArgs(process.argv.slice(2));
const PORT = Number(opts.port || process.env.JUDGE_PORT) || 8787;
const HOST = opts.host || '127.0.0.1';
const TOKEN = String(opts.token || process.env.JUDGE_TOKEN || '');

const judge = createJudge({
  apiKey: opts.key || process.env.DEEPSEEK_API_KEY || '',
  baseUrl: opts.baseUrl,
  model: opts.model,
  examplesFile: opts.examples,
  logFile: opts.log || 'judge-log.jsonl',
  logger: (m) => console.log(`[judge-server] ${m}`),
});

function json(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
  });
  res.end(body);
}

function authorized(req) {
  if (!TOKEN) return true;
  return req.headers.authorization === `Bearer ${TOKEN}`;
}

function readBody(req, limit = 256 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(new Error('body too large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = (req.url || '/').split('?')[0];
  try {
    if (req.method === 'GET' && url === '/health') {
      return json(res, 200, { ok: true, examples: judge.exampleCount(), used: judge.stats().used });
    }

    if (url === '/reload' && req.method === 'POST') {
      if (!authorized(req)) return json(res, 401, { error: 'unauthorized' });
      const n = judge.reloadExamples();
      return json(res, 200, { ok: true, examples: n });
    }

    if (url === '/judge' && req.method === 'POST') {
      if (!authorized(req)) return json(res, 401, { error: 'unauthorized' });
      let body;
      try {
        body = JSON.parse((await readBody(req)).replace(/^\uFEFF/, ''));
      } catch {
        return json(res, 400, { error: 'body 不是合法 JSON（或超过 256KB）' });
      }
      const messages = body && body.messages;
      if (!Array.isArray(messages) || !messages.length) {
        return json(res, 400, { error: 'messages 必须是非空数组' });
      }
      const callOpts = (body && body.opts) || {};
      const out = await judge.shouldSpeak(messages, callOpts);
      return json(res, 200, out);
    }

    if (url === '/judge' || url === '/reload') {
      return json(res, 405, { error: 'method not allowed' });
    }
    return json(res, 404, { error: 'not found' });
  } catch (e) {
    console.error('[judge-server] 500', e);
    return json(res, 500, { error: String((e && e.message) || e) });
  }
});

server.on('error', (e) => {
  console.error('[judge-server] 启动失败：' + String((e && e.message) || e));
  process.exit(1);
});

server.listen(PORT, HOST, () => {
  console.log(`[judge-server] http://${HOST}:${PORT}  model=${opts.model || 'deepseek-chat'} ` +
    `examples=${judge.exampleCount()}  auth=${TOKEN ? 'on' : 'off'}`);
  if (!TOKEN) console.log('[judge-server] 没设口令（--token / JUDGE_TOKEN）；只监听本机时可以不管。');
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => {
    console.log('\n[judge-server] 关闭');
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 1500);
  });
}
